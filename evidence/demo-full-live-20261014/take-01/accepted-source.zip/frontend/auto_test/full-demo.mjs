import assert from 'node:assert/strict';
import { expect } from '@playwright/test';
import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { familyJourney } from './full-demo-family.mjs';
import { moneyJourney, trustJourney } from './full-demo-money.mjs';

export function configure(h) {
  const { page, context, origin, output, recording, get, say } = h;
  const checks = [];
  h.read = route => get(context, route);
  h.mark = async (name, hold = 6) => {
    console.log('SHOT', name);
    await recording.mark(page, name, hold);
    await page.screenshot({ path: fileURLToPath(new URL(`${name}.png`, output)) });
  };
  h.check = (name, data = {}) => {
    checks.push({ name, passed: true, ...data });
    writeFileSync(new URL('coverage.json', output), JSON.stringify(checks, null, 2));
    console.log('PASS', name);
  };
  h.open = async (tool, section = '') => {
    await page.goto(`${origin}/?tool=${tool}${section ? '&section=' + encodeURIComponent(section) : ''}`);
    const expand = page.getByRole('button', { name: 'Expand tool', exact: true });
    if (await expand.count()) await expand.click();
  };
  h.close = async () => {
    const close = page.getByRole('button', { name: 'Close tool', exact: true });
    if (await close.count()) await close.click();
  };
  h.ask = async text => { await h.close(); return say(page, text); };
  return {
    async cost() {
      const result = await h.ask('What is the total cost of the full programme at PSU Phuket? Include tuition, housing and living costs, and essential costs.');
      const card = result.cards.find(c => c.type === 'cost');
      assert.ok(card?.estimate?.lines?.length);
      assert.ok(Number(card.estimate.total) > 0);
      await h.mark('single-school-total');
      await page.locator('.price-card').first().getByRole('button', { name: /View details/ }).click();
      await h.mark('cost-tuition');
      for (const [index, name] of [[1, 'cost-living'], [2, 'cost-essentials']]) {
        await page.locator('.panel-grid-3 button').nth(index).click();
        await h.mark(name, 4);
      }
      h.check('Single-school full-course estimate with sourced and estimated lines', { total: card.estimate.total });
      await h.close();
    },
    async currencies() {
      for (const currency of ['CNY', 'USD', 'THB']) {
        await page.locator('.currency-switch').getByRole('button', { name: currency, exact: true }).click();
        await h.mark(`comparison-${currency}`, 4);
      }
      h.check('Four-school comparison and THB/CNY/USD display');
    },
    async loanMethods(chooser) {
      await chooser.getByRole('radio', { name: /Interest only while studying/ }).check();
      await expect(chooser.locator('tbody tr.is-study')).toHaveCount(42);
      await h.mark('loan-interest-only');
      await chooser.getByRole('radio', { name: 'Monthly principal and interest from the start', exact: true }).check();
      await expect(chooser.locator('tbody tr.is-study')).toHaveCount(0);
      h.check('Both repayment methods and full schedules', { studyMonths: 42, repaymentMonths: 60 });
    },
    async preparation() {
      await h.ask('Remind me tomorrow to submit housing documents.');
      const life = await h.read('planning/life/');
      const task = life.items.find(i => /housing documents/i.test(typeof i.title === 'string' ? i.title : i.title.en));
      assert.ok(task);
      assert.equal(task.due_date, '2027-08-02');
      await h.open('life', task.source_key);
      await h.mark('preparation-reminder');
      const detail = page.locator('.life-detail');
      await detail.getByRole('button', { name: 'Got it', exact: true }).click();
      await expect(detail.getByRole('button', { name: 'Got it', exact: true })).toHaveCount(0);
      await page.reload();
      assert.equal((await h.read('planning/life/')).items.find(i => i.source_key === task.source_key).unread, false);
      await page.locator('.life-detail').getByRole('button', { name: 'Mark completed', exact: true }).click();
      await h.mark('preparation-completed', 3);
      h.check('Live AI reminder, persisted acknowledgement and completion');
      await h.open('funding');
    },
    async afterRepayment() {
      h.check('Loan application, checklist, signing, school payouts and wallet repayment');
      await familyJourney(h);
      await enrollAndBudget(h);
      await moneyJourney(h);
      await creditDeclarations(h);
      await trustJourney(h);
    },
  };
}

async function enrollAndBudget(h) {
  const { page } = h;
  assert.equal((await h.read('planning/profile/')).plan.status, 'CONFIRMED');
  await h.ask('I have completed registration at PSU Phuket and arrived on campus. Please confirm my enrollment.');
  const card = page.locator('.plan-card-confirm').filter({ hasText: /enrollment/i }).last();
  await h.mark('enrollment-proposal');
  assert.equal((await h.read('planning/profile/')).plan.status, 'CONFIRMED');
  await card.getByRole('button', { name: 'Confirm', exact: true }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Confirm', exact: true }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
  assert.equal((await h.read('planning/profile/')).plan.status, 'ENROLLED');
  await h.mark('enrolled');
  h.check('Explicit enrollment with user confirmation; date alone did not enroll');
  await h.open('life');
  await page.locator('.life-summary').getByRole('button', { name: 'Edit budget' }).click();
  await page.locator('.life-summary form input').fill('6000');
  await page.locator('.life-summary form').getByRole('button', { name: 'Save', exact: true }).click();
  await h.mark('monthly-budget');
  assert.equal((await h.read('planning/life/')).budget.budget, '6000.00');
  await h.ask('Record that I spent 120 THB on lunch today.');
  let life = await h.read('planning/life/');
  assert.equal(life.budget.spent, '120.00');
  assert.equal(life.budget.remaining, '5880.00');
  await h.open('life');
  await page.locator('.life-spending').scrollIntoViewIfNeeded();
  await h.mark('expense-recorded');
  await page.getByRole('button', { name: 'Undo entry' }).click();
  await expect(page.getByRole('button', { name: 'Undo entry' })).toHaveCount(0);
  life = await h.read('planning/life/');
  assert.equal(life.budget.remaining, '6000.00');
  await h.mark('expense-undone', 3);
  h.check('Budget edit, live AI expense, categories and undo', { remaining: life.budget.remaining });
}

async function creditDeclarations(h) {
  const before = await h.read('demo/wallets/balances/');
  const line = await h.read('planning/credit/');
  const life = await h.read('planning/life/');
  const bill = life.items.find(i => i.kind === 'bill' && !i.done && !i.paid_by_loan && Number(i.amount) > 0 && Number(i.amount) < Number(line.available));
  assert.ok(bill, 'A bill within the fixed credit line');
  await h.open('life', bill.source_key);
  await h.page.getByRole('button', { name: 'Pay with credit', exact: true }).click();
  await h.mark('credit-used');
  const used = await h.read('planning/credit/');
  assert.equal(used.used, bill.amount);
  const charge = used.charges.find(c => c.bill_id === bill.source_key.split(':')[1]);
  await h.open('life', `credit:${charge.id}`);
  await h.mark('credit-repayment-declaration');
  await h.page.getByRole('button', { name: 'Record as repaid', exact: true }).click();
  await h.mark('credit-restored', 4);
  assert.equal((await h.read('planning/credit/')).used, '0.00');
  assert.deepEqual((await h.read('demo/wallets/balances/')).balances, before.balances);
  h.check('Fixed demo credit use and repayment declaration', { walletMoved: false, amount: bill.amount });
}
