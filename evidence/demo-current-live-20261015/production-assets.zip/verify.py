"""Verify this film's live evidence, captions, source ranges and final audio/video."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

from PIL import Image, ImageChops, ImageStat

ROOT = Path.cwd()
WORK = ROOT / "output/formal-film-production"
DEST = WORK / "candidate"
sys.path.insert(0, str(ROOT / "scripts"))
import verify_neural_demo as media
import verify_full_demo as frames
from neural_demo_audio import FFMPEG, normalized

media.DEST = DEST
media.WORK = WORK
frames.DEST = DEST


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def evidence(take):
    browser = read(take / "browser.json")
    assert browser["success"] and not browser["pageErrors"], browser
    assert read(take / "source-check.json")["unchanged"]
    manifest = read(take / "source-manifest.json")
    with zipfile.ZipFile(take / "accepted-source.zip") as archive:
        assert set(archive.namelist()) == set(manifest)
        for name, digest in manifest.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == digest, name
    turns = read(take / "turns.json")
    assert len(turns) >= 19
    for turn in turns:
        assert turn["mode"] == "live" and turn["status"] == "COMPLETED"
        modes = [s["call"].get("mode", "system") for s in turn["steps"]]
        assert "live" in modes and not {"mock", "rules"}.intersection(modes), turn["goal"]
    checks = read(take / "coverage.json")
    assert all(item["passed"] for item in checks)
    assert any("independent approval" in item["name"] for item in checks)
    assert any("installment repaid" in item["name"] for item in checks)
    trace = read(take / "model-trace.json")
    assert not {"mock", "rules"}.intersection(trace["call_modes"])
    source_hashes = {}
    for source in read(take / "sources.json"):
        path = take / source["path"]
        source_hashes[source["path"]] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {"source_files_verified": len(manifest), "live_conversation_turns": len(turns),
            "acceptance_checks": len(checks), "call_modes": trace["call_modes"],
            "live_attempts": trace["live_attempts"], "models": [m for m in trace["models"] if m],
            "raw_video_sha256": source_hashes, "no_rule_or_mock_fallback": True}


def captions(edit):
    assert normalized(" ".join(c["text"] for c in edit["captions"])) == normalized(
        " ".join(p["text"] for p in edit["paragraphs"]))
    prior = 0
    for caption in edit["captions"]:
        shot = next(s for s in edit["shots"] if s["id"] == caption["shot"])
        assert prior <= caption["start"] < caption["end"] <= shot["start"] + shot["duration"] + 1e-7
        assert caption["start"] >= shot["start"]
        prior = caption["end"]
    prior = 0
    for shot in edit["shots"]:
        assert abs(shot["start"] - prior) < .001
        assert abs(shot["start"] * 30 - round(shot["start"] * 30)) < .001
        prior += shot["duration"]
    return {"shots": len(edit["shots"]), "continuous_paragraphs": len(edit["paragraphs"]),
            "caption_groups": len(edit["captions"]), "captions_within_matching_shot": True,
            "caption_text_matches_narration": True}


def stable_end_frames(movie, edit):
    """Check the final held frame as well as the original source-range starting frame."""
    checks = []
    for shot in edit["shots"]:
        if shot["source"]["range"] != "recorded held view":
            continue
        position = shot["start"] + shot["duration"] - .12
        result = subprocess.run([str(FFMPEG), "-v", "error", "-ss", str(position), "-i", str(movie),
            "-frames:v", "1", "-vf", "crop=1440:900:24:58,scale=360:225", "-pix_fmt", "rgb24",
            "-f", "rawvideo", "-"], capture_output=True, check=True)
        actual = Image.frombytes("RGB", (360, 225), result.stdout)
        with Image.open(Path(edit["take"]) / shot["source"]["screenshot"]) as reference:
            delta = ImageChops.difference(actual, reference.convert("RGB").resize((360, 225)))
        error = sum(ImageStat.Stat(delta).mean) / 3
        item = {"shot": shot["id"], "marker": shot["marker"], "difference": error}
        assert error < 4, item
        checks.append(item)
    return checks


def main():
    edit = read(DEST / "edit-manifest.json")
    movie = DEST / "StudyFlow_Demo_EN.mp4"
    result = {**evidence(Path(edit["take"])), **captions(edit)}
    print("Evidence and captions verified", flush=True)
    result.update(media.verify_clock(movie, edit["duration"]))
    print("Media clock and full decode verified", flush=True)
    placement = media.verify_waveform(movie, edit["shots"])
    result.update(media.verify_levels(movie))
    tails = stable_end_frames(movie, edit)
    sheets = frames.frame_contact(str(FFMPEG), movie, edit["shots"])
    with Image.open(DEST / "qa-shot-01.png") as poster:
        poster.save(DEST / "StudyFlow_Demo_EN_Poster.png")
    result.update({"passed": True, "sha256": hashlib.sha256(movie.read_bytes()).hexdigest(),
        "narration_alignment": placement,
        "held_frame_checks": tails,
        "max_narration_offset_seconds": max(abs(c["offset_seconds"]) for c in placement),
        "timing_method": "Provider word events mapped through actual PCM tempo regions; sentence cuts at 30 fps; final AAC compared to scheduled PCM",
        "timing_limit": "1 ms waveform measurement verifies encoding placement. Provider word events are not independent phonetic ground truth.",
        "contact_sheets": [Path(p).name for p in sheets],
        "visual_review": "Pending inspection of every contact sheet and key full-size frames"})
    (DEST / "verification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k not in ("narration_alignment", "held_frame_checks")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
