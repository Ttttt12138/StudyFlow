"""Publish verified take-08 media at the single existing canonical entry."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

from release_notes import readme, narration
from sentence_patch import verify_originals

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
SOURCE = WORK / "candidate"
DEST = ROOT / "evidence/demo-current-live-20261015"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8", newline="\n")


def unchanged_evidence(take):
    recorded = read(WORK / "take-08-before.json")
    actual = {p.relative_to(take).as_posix(): digest(p) for p in take.rglob("*") if p.is_file()}
    assert recorded == actual, "The accepted take must remain immutable"
    manifest = read(take / "source-manifest.json")
    assert all(digest(ROOT / name) == checksum for name, checksum in manifest.items())


def gate():
    report, edit = read(SOURCE / "verification.json"), read(SOURCE / "edit-manifest.json")
    assert report["passed"] and report["visual_review"]["passed"]
    assert report["sha256"] == digest(SOURCE / "StudyFlow_Demo_EN.mp4") == report["visual_review"]["video_sha256"]
    assert report["av_endpoint_difference_seconds"] <= 1 / 30 and edit["duration"] < 300
    assert len(edit["shots"]) == 54 and len(edit["paragraphs"]) == 8
    take = Path(edit["take"]).resolve()
    assert take.name == "take-08" and all(Path(s["source"]["path"]).resolve().is_relative_to(take) for s in edit["shots"])
    assert read(SOURCE / "speech-check.json")["numbers_match"]
    assert read(SOURCE / "replacement-speech-check.json")["vocabulary_pass"]["passed"]
    unchanged_evidence(take)
    verify_originals()
    return edit, report


def production_archive():
    names = {"produce.py", "verify.py", "release.py", "release_notes.py", "qa_frames.py", "check_speech.py",
        "check_replacement_speech.py", "synthesize_replacement.py", "sentence_patch.py", "neural_demo_audio.py",
        "story.json", "speech-service.json", "original-speech-service.json", "audio-timeline.json", "captions.ass",
        "continuous-narration.wav", "original-production-manifest.json", "source-cuts.json", "sentence-replacement.json",
        "audio-preservation.json", "chapter-06.composite.json", "chapter-06-patched.wav", "exchange-seam-preview.mp3",
        "auto_test/test_sentence_patch.py", "take-08-before.json"}
    names.update(p.name for p in WORK.glob("*.mp3"))
    names.update(p.name for p in WORK.glob("*.tts.json"))
    manifest = {name: digest(WORK / name) for name in sorted(names)}
    target = SOURCE / "production-assets.zip"
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for name in manifest:
            archive.write(WORK / name, name)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(manifest)
        assert all(hashlib.sha256(archive.read(name)).hexdigest() == checksum for name, checksum in manifest.items())
    save(SOURCE / "production-manifest.json", manifest)
    return {"entries": len(manifest), "sha256": digest(target), "crc_and_entry_hashes_verified": True}


def replace_preserving_newlines(path, replacements):
    original = path.read_bytes()
    result = original
    for old, new in replacements:
        result = result.replace(old.encode("utf-8"), new.encode("utf-8"))
    if result != original:
        path.write_bytes(result)


def update_indexes():
    for name in ["README.md", "evidence/demo-full-live-20261014/README.md"]:
        replace_preserving_newlines(ROOT / name, [("4:25", "4:28")])
    replace_preserving_newlines(ROOT / "docs/security-self-assessment.md", [
        ("The current 4:25 film uses the new October 15 acceptance:", "The current 4:28 film uses take-08 from October 17:"),
        ("Only that script was sent; browser recordings", "For the take-08 update, only one approved exchange sentence was synthesized again; the other recordings were reused. Only English narration text was sent; browser recordings")])
    replace_preserving_newlines(ROOT / "docs/technical-overview.md", [
        ("[October 15 recording and evidence]", "[October 17 take-08 recording and evidence]"),
        ("55 provider attempts", "57 provider attempts"),
        ("new 4:25 Ava film with 54 shots", "4:28 Ava film with all 54 shots from take-08 and all 82 audit events preserved")])
    replace_preserving_newlines(ROOT / "docs/third-party-licenses.md", [
        ("The current October 14 full-flow film", "The current October 17 take-08 full-flow film"),
        ("Twelve complete paragraphs were synthesized at `rate=-10%`, then processed locally at 1.20× tempo, matching the approved audition; five numeric sentences use 1.12× for clarity.",
         "The film reuses eight continuous paragraph recordings synthesized at `rate=-10%`, processed locally at 1.20× tempo, matching the approved audition; selected numeric sentences use 1.12× for clarity. For the take-08 revision, only the approved exchange sentence in paragraph six was sent again and spliced locally, at 1.12× tempo. All original MP3s and provider metadata remain in the production archive; the seven unaffected mastered paragraphs are unchanged.")])
    replace_preserving_newlines(ROOT / "evidence/README.md", [("4:25", "4:28"), ("take-07", "take-08"),
        ("newest 50 of 82: reminders, exchange, remittance, approval, tuition and repayment", "all 82 events, every API page exported, including reminders, exchange, remittance, approval, tuition and repayment"),
        ("simulated-account operation logs | live LLM / fixture FX / simulated funds | 2026-10-15", "complete simulated-account operation logs | live LLM / fixture FX / simulated funds | 2026-10-17")])


def main():
    edit, report = gate()
    report["production_archive"] = production_archive()
    report["delivery_source_check"] = read(SOURCE / "delivery-source-check.json")
    save(SOURCE / "verification.json", report)
    (SOURCE / "README.md").write_text(readme(edit, report), encoding="utf-8", newline="\r\n")
    save(SOURCE / "replacement.json", {"take": "take-08", "date": "2026-10-17", "sha256": report["sha256"],
        "duration": edit["duration"], "paths": [str((DEST / "StudyFlow_Demo_EN.mp4").relative_to(ROOT))],
        "previous_version": "Git history; no duplicate submission video created"})
    for path in SOURCE.iterdir():
        if path.is_file():
            if path.suffix in {".json", ".srt", ".txt", ".log"}:
                clean = b"\n".join(line.rstrip(b" \t\r") for line in path.read_bytes().split(b"\n"))
                path.write_bytes(clean)
            shutil.copy2(path, DEST / path.name)
    (ROOT / "docs/demo-video-en.md").write_text(narration(edit), encoding="utf-8", newline="\n")
    update_indexes()
    unchanged_evidence(Path(edit["take"]))
    assert digest(DEST / "StudyFlow_Demo_EN.mp4") == report["sha256"]
    print(json.dumps({"video": str(DEST / "StudyFlow_Demo_EN.mp4"), "duration": edit["duration"],
                      "sha256": report["sha256"], "production_archive": report["production_archive"]}, indent=2))


if __name__ == "__main__":
    main()
