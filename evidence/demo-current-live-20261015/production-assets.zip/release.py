"""Publish verified local deliverables and retain the previous formal version."""
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path.cwd()
WORK = ROOT / "output/formal-film-production"
SOURCE = WORK / "candidate"
DEST = ROOT / "evidence/demo-current-live-20261015"
OLD = ROOT / "evidence/demo-full-live-20261014"
MIRROR = ROOT / "evidence/demo-live-20261014"
MEDIA = ["StudyFlow_Demo_EN.mp4", "StudyFlow_Demo_EN.srt", "StudyFlow_Demo_EN_Poster.png",
         "edit-manifest.json", "verification.json", "media-inspection.txt", "audio-inspection.txt",
         "visual-review.json"]


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clock(seconds):
    whole = round(seconds)
    return f"{whole // 60:02d}:{whole % 60:02d}"


def main():
    report, edit = read(SOURCE / "verification.json"), read(SOURCE / "edit-manifest.json")
    assert report["passed"] and report["visual_review"]["passed"]
    assert digest(SOURCE / MEDIA[0]) == report["sha256"]
    take = Path(edit["take"])
    source_manifest = read(take / "source-manifest.json")
    source_changes = [{"path": name, "recorded_sha256": checksum, "current_sha256": digest(ROOT / name)}
                      for name, checksum in source_manifest.items() if digest(ROOT / name) != checksum]
    assert {item["path"] for item in source_changes} <= {"studyflow-ai/auto_test/test_planning_rules.py"}
    delivery_check = {"runtime_source_unchanged": True, "snapshot_file_count": len(source_manifest),
        "post_recording_changes": source_changes,
        "explanation": "Only the prompt-version test assertion was updated from planning-2.4 to planning-2.6 after recording; all 21 planning-rule tests then passed. Recorded application code is unchanged."}
    (SOURCE / "delivery-source-check.json").write_text(json.dumps(delivery_check, indent=2), encoding="utf-8", newline="\n")
    report["delivery_source_check"] = delivery_check
    (SOURCE / "verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8", newline="\n")
    # Python's Windows text writes default to CRLF; keep release metadata consistent
    # with the repository's existing LF files without altering recorded raw evidence.
    for path in SOURCE.iterdir():
        if path.is_file() and path.suffix in {".md", ".json", ".srt", ".txt"}:
            data = path.read_bytes()
            clean = b"\n".join(line.rstrip(b" \t\r") for line in data.split(b"\n"))
            if clean != data:
                path.write_bytes(clean)
    previous = DEST / "previous-formal-ava-20261014.zip"
    if not previous.exists():
        with zipfile.ZipFile(previous, "x", zipfile.ZIP_DEFLATED) as archive:
            for name in [*MEDIA, "README.md", "replacement.json"]:
                path = OLD / name
                if path.exists():
                    archive.write(path, "demo-full-live-20261014/" + name)
            archive.write(ROOT / "docs/demo-video-en.md", "docs/demo-video-en.md")
            archive.write(MIRROR / "README.md", "demo-live-20261014/README.md")
    for path in SOURCE.iterdir():
        if path.is_file():
            shutil.copy2(path, DEST / path.name)
    shutil.copy2(WORK / "financial-regression.log", DEST / "financial-regression.txt")
    for folder in (OLD, MIRROR):
        for name in MEDIA:
            shutil.copy2(DEST / name, folder / name)
        (folder / "README.md").write_text(
            "# Formal English demo — stable link\n\n"
            "[Watch the current film](StudyFlow_Demo_EN.mp4) · "
            "[Current acceptance, original recordings and production notes](../demo-current-live-20261015/README.md)\n\n"
            f"Updated on 2026-10-15: **{clock(edit['duration'])}**, Ava narration, current student loan flow and "
            "independent operations approval. The MP4, SRT, poster, edit manifest and verification report here mirror the current release.\n\n"
            "The earlier formal film and its original metadata are preserved in "
            "[this archive](../demo-current-live-20261015/previous-formal-ava-20261014.zip). "
            "Other dated takes, logs, contact sheets and production assets in this folder are historical evidence; "
            "use the current acceptance folder for this film.\n", encoding="utf-8")
    manifest = {}
    names = {"produce.py", "verify.py", "release.py", "check_speech.py", "story.json",
             "speech-service.json", "audio-timeline.json", "captions.ass", "continuous-narration.wav"}
    assets = [p for p in WORK.iterdir() if p.is_file() and
              (p.name in names or p.suffix == ".mp3" or p.name.endswith(".tts.json"))]
    with zipfile.ZipFile(DEST / "production-assets.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in assets:
            archive.write(path, path.name)
            manifest[path.name] = digest(path)
    (DEST / "production-manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    duration = clock(edit["duration"])
    lines = ["# StudyFlow — Current Formal English Demo", "",
        "[Watch the formal video](StudyFlow_Demo_EN.mp4) · [English subtitles](StudyFlow_Demo_EN.srt) · "
        "[Verification](verification.json)", "",
        f"Runtime: **{duration}** ({edit['duration']:.3f} seconds), 1920 × 1080, 30 fps. "
        f"{report['shots']} feature shots in {report['continuous_paragraphs']} connected narration paragraphs. "
        "Microsoft `en-US-AvaNeural`, synthesis `-10%`, local tempo `1.20`; key amount sentences use `1.12`. "
        "The user authorized sending the English narration to Microsoft. No Chinese review copy is included.", "",
        "## Current acceptance", "",
        f"The film uses **{take.name}**, recorded on 2026-10-15 against the working tree based on commit "
        f"`{read(take / 'baseline.json')['commit']}`. The frozen source archive, per-file hashes and post-run "
        "hash check identify the actual version, including the recorded fixes. This is a live browser acceptance "
        "run and production replay, not a new frozen model benchmark.", "",
        f"**{report['live_conversation_turns']} user turns**, **{report['acceptance_checks']} checked scenarios**. "
        f"Call modes: `{json.dumps(report['call_modes'])}`. "
        "Every conversational request invoked the external model; deterministic server replies are counted "
        "separately. No rule or mock fallback occurred in the accepted take. "
        f"Model: `{', '.join(report['models'])}`; prompt `planning-2.6`.", "",
        "[Delivery source check](delivery-source-check.json): recorded application code still matches the accepted "
        "snapshot. After recording, the planning-rule test's expected prompt version was updated from "
        "`planning-2.4` to `planning-2.6`; all 21 tests in that file then passed. The original source snapshot is preserved.", "",
        "All wallets, loans, university notices, payments and approvals are simulated in a disposable PostgreSQL "
        "test database. FX is fixture-based; school costs are sourced sample data and estimates. "
        "The student, payee verifier and approver are separate synthetic accounts. Actual UI interactions and "
        "server persistence are exercised; approval simulation is disabled so the separate staff account decides. "
        "Setup includes a CNY 30,000 simulated top-up, a synthetic housing payee and a THB 10,000 repayment top-up. "
        "These setup API calls are recorded in the harness, not described as AI actions.", "",
        f"[Uncut role recordings]({take.name}/raw/) · [Conversation and tool results]({take.name}/turns.json) · "
        f"[Full model trace]({take.name}/model-trace.json) · [Scenario assertions]({take.name}/coverage.json) · "
        f"[Frozen source]({take.name}/accepted-source.zip) · [Source hash check]({take.name}/source-check.json)", "",
        "## Coverage and failures retained", "",
        "The current path covers costs and sources; four-school and THB/CNY/USD comparison; missing-data disclosure; "
        "school selection; borrowing amount, alternative loans, monthly-payment/interest tradeoffs and study-period "
        "payments; manual loan controls; pause/resume and stale-quote rejection; explicit application, simulated notice, "
        "documents and signing; school-directed payouts; reminders with completion and undo; split tuition and "
        "password-authorized wallet payment; exchange, wrong-password denial, remittance and delivery; loan repayment; "
        "over-limit rejection, payee verification, separation of duties, independent approval and final student submission.", "",
        "Earlier attempts are retained, not counted as passes: take-01 used a currency selector that omitted the "
        "currency symbol; take-02 clicked behind an automatically opened application review; take-03 exposed the "
        "model incorrectly treating default loan inputs as explicit preferences; take-04 checked an asynchronous "
        "checkbox before its server update; take-05 unnecessarily listed the full catalog before comparing four "
        "named schools, so the intended comparison card was suppressed. The prompt now calls the named-school "
        "comparison directly. See each take's browser log and frozen source. "
        "Take-06 stopped on a recorder selector that matched both the main panel and signing dialog; "
        "the dialog is now selected by its exact title. "
        "The model prompt now distinguishes defaults from explicit preferences; malformed JSON-tail replies are "
        "retried instead of shown. The 127 focused planner tests, 21 planning-rule tests and targeted Ruff check passed.", "",
        "The [10 financial regression tests](financial-regression.txt) additionally exercise wallet-bill and "
        "operations permissions against a separate test database. Their authenticated duplicate-payment case "
        "verifies the loan-covered bill guard. The uncredentialed duplicate call in the live browser harness "
        "only establishes step-up denial; it is not evidence of that deeper guard by itself.", "",
        "## Editing and verification", "",
        "The formal edit removes waiting and uses actual recorded frames. Review shots retain the recorded click "
        "and resulting state where practical; stable frames may be held for the narration. No fabricated product "
        "screens or substituted AI responses are used. The uncut role recordings preserve the full operations.", "",
        "The final student authorization was brief in the automated recording. Its actual masked-password frame "
        "at 536.800 seconds of the student recording is held while that step is narrated; the following shot "
        "shows the recorded confirmed result. This frame is extracted from the accepted raw video.", "",
        f"Full decoding passed. Audio/video endpoint difference: {report['av_endpoint_difference_seconds']:.6f} s. "
        f"Maximum measured narration placement difference: {report['max_narration_offset_seconds']:.3f} s. "
        "Every caption matches the narration text and stays inside its corresponding shot. "
        "Provider word timing is mapped through local tempo changes; waveform checks verify encoding placement, "
        "not independent phonetic alignment. Contact sheets and selected full-resolution frames were reviewed.", "",
        "The [offline speech check](speech-check.json) recovered all spoken amounts. Recognition differences "
        "are not a human listening score; no audio was uploaded for this local check.", "",
        "[Edit manifest](edit-manifest.json) · [Source-frame alignment](source-alignment.json) · "
        "[Production archive](production-assets.zip) · [Production hashes](production-manifest.json)", "",
        "Reproduce from the repository root with `studyFlow/Scripts/python.exe -B -X utf8 scripts/run_formal_demo.py <new-take>`. "
        "This needs configured live-model credentials and PostgreSQL, and creates its own test database. "
        "For media reproduction, extract the production archive into `output/formal-film-production/`, then run "
        "`produce.py prepare --take evidence/demo-current-live-20261015/" + take.name + "`, `produce.py render`, "
        "and `verify.py` using the project interpreter. Speech MP3s and provider word events are included; "
        "no new external speech call is needed to reproduce the edit.", "",
        "## Previous version", "",
        "[Previous 4:05 Ava formal film and metadata](previous-formal-ava-20261014.zip). "
        "Both older stable MP4 links now contain this current version. Historical acceptance remains historical.", "",
        f"SHA-256: `{report['sha256']}`", ""]
    (DEST / "README.md").write_text("\n".join(lines), encoding="utf-8")
    document = ["# StudyFlow — Formal English Product Narrative", "",
        "[Current formal video](../evidence/demo-current-live-20261015/StudyFlow_Demo_EN.mp4) · "
        "[Current acceptance and originals](../evidence/demo-current-live-20261015/README.md)", "",
        f"Runtime: **{duration}** ({edit['duration']:.3f} seconds). {report['shots']} shots, "
        f"{report['continuous_paragraphs']} continuous paragraphs. Ava voice and pace retained: "
        "`en-US-AvaNeural`, synthesis `-10%`, local tempo `1.20` with selected amount sentences at `1.12`. "
        "StudyFlow is spoken as Study Flow; amounts are spelled out. All financial transactions are simulated.", "",
        "## Continuous narration", ""]
    for chapter in edit["paragraphs"]:
        document += [f"### {clock(chapter['start'])}–{clock(chapter['start'] + chapter['duration'])} · {chapter['title']}", "", chapter["text"], ""]
    document += ["## Complete shot coverage", "", "| Shot | Time | Visible feature |", "|---|---|---|"]
    for shot in edit["shots"]:
        document.append(f"| {shot['number']:02d} | {clock(shot['start'])}–{clock(shot['start'] + shot['duration'])} | {shot['title']} |")
    document += ["", "See the current evidence README for the accepted source snapshot, failed attempts, mode boundaries, "
                 "authorization checks and synchronization measurements.", ""]
    (ROOT / "docs/demo-video-en.md").write_text("\n".join(document), encoding="utf-8")
    replacement = {"sha256": report["sha256"], "duration": edit["duration"], "take": take.name,
                   "paths": [str((p / MEDIA[0]).relative_to(ROOT)) for p in (DEST, OLD, MIRROR)],
                   "copies_identical": all(digest(p / MEDIA[0]) == report["sha256"] for p in (DEST, OLD, MIRROR))}
    assert replacement["copies_identical"]
    (DEST / "replacement.json").write_text(json.dumps(replacement, indent=2), encoding="utf-8")
    for folder in (OLD, MIRROR):
        shutil.copy2(DEST / "replacement.json", folder / "replacement.json")
    generated_text = [ROOT / "docs/demo-video-en.md", *(p for folder in (DEST, OLD, MIRROR)
                      for p in folder.iterdir() if p.is_file() and p.name in {"README.md", "replacement.json", "production-manifest.json"})]
    for path in generated_text:
        path.write_bytes(path.read_bytes().replace(b"\r\n", b"\n"))
    print(json.dumps(replacement, indent=2))


if __name__ == "__main__":
    main()
