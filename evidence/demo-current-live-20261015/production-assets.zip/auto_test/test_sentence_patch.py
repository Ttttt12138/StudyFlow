"""Meaningful invariants for a sentence-only replacement, including unequal lengths."""
import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from sentence_patch import splice_pcm, splice_boundaries


class SentenceReplacementTests(unittest.TestCase):
    def test_splice_preserves_every_original_sample_outside_target(self):
        original = bytes(range(100))
        replacement = b"\xff\x00" * 23
        result = splice_pcm(original, replacement, (10, 20))
        self.assertEqual(result[:20], original[:20])
        self.assertEqual(result[20:66], replacement)
        self.assertEqual(result[66:], original[40:])
        self.assertEqual(len(result), len(original) + len(replacement) - 20)

    def test_retiming_keeps_words_and_rebases_only_replaced_and_following_events(self):
        def event(text, second):
            return {"type": "WordBoundary", "text": text, "offset": int(second * 1e7), "duration": 500000}
        old = [event("before", 0.1), event("old", 0.5), event("after", 0.9)]
        new = [event("new", 0.1), event("words", 0.4)]
        result = splice_boundaries(old, new, {"left": .4, "right": .8, "trim_start": .05, "insert_duration": .7})
        self.assertEqual([e["text"] for e in result], ["before", "new", "words", "after"])
        self.assertEqual([e["offset"] for e in result], [1000000, 4500000, 7500000, 12000000])
        self.assertEqual(old[2]["offset"], 9000000)


if __name__ == "__main__":
    unittest.main()
