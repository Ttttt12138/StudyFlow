"""Independent, offline recognition of the changed sentence and both joins."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

WORK = Path(__file__).resolve().parent
os.environ["CUDA_CACHE_PATH"] = str(WORK / "validation-cache/cuda")
os.environ["HF_HUB_OFFLINE"] = "1"


def main():
    import numpy as np
    import whisper
    model_file = Path("C:/Users/南陌/Documents/Codex/2026-09-29/chu/work/models/large-v3-turbo.pt")
    digest = hashlib.sha256(model_file.read_bytes()).hexdigest()
    assert digest == whisper._MODELS["turbo"].split("/")[-2]
    ffmpeg = Path.cwd() / "output/video-tools/imageio_ffmpeg/binaries/ffmpeg-win-x86_64-v7.1.exe"
    wave = subprocess.run([str(ffmpeg), "-v", "error", "-i", str(WORK / "exchange-seam-preview.mp3"),
                           "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], capture_output=True, check=True)
    model = whisper.load_model(str(model_file), device="cuda")
    samples = np.frombuffer(wave.stdout, dtype=np.float32).copy()
    result = model.transcribe(samples, language="en", temperature=0,
                              beam_size=5, condition_on_previous_text=False, word_timestamps=True)
    text = result["text"].strip()
    normalized = re.sub(r"[^a-z0-9]", "", text.lower().replace("five hundred", "500"))
    phrases = ["after password confirmation", "500 yuan is debited", "Thai baht", "credited after fees"]
    checks = {phrase: re.sub(r"[^a-z0-9]", "", phrase.lower()) in normalized for phrase in phrases}
    report = {"model": "Whisper large-v3-turbo", "model_sha256": digest,
              "audio_sha256": hashlib.sha256((WORK / "exchange-seam-preview.mp3").read_bytes()).hexdigest(),
              "offline": True, "initial_prompt": None, "transcript": text, "phrase_checks": checks,
              "passed": all(checks.values()), "segments": result["segments"],
              "scope": "Final mastered sentence plus preceding and following narration; independent ASR, not a human listening score"}
    # Preserve the unprompted result. A vocabulary-only second pass resolves proper
    # currency names without giving the recognizer the expected sentence or amounts.
    hint = "Currency names: yuan, Thai baht."
    vocabulary = model.transcribe(samples, language="en", temperature=0, beam_size=5,
                                  condition_on_previous_text=False, initial_prompt=hint)
    vocabulary_text = vocabulary["text"].strip()
    value = re.sub(r"[^a-z0-9]", "", vocabulary_text.lower().replace("five hundred", "500"))
    vocabulary_checks = {phrase: re.sub(r"[^a-z0-9]", "", phrase.lower()) in value for phrase in phrases}
    report["vocabulary_pass"] = {"initial_prompt": hint, "transcript": vocabulary_text,
                                 "phrase_checks": vocabulary_checks, "passed": all(vocabulary_checks.values())}
    (WORK / "candidate/replacement-speech-check.json").write_text(json.dumps(report, indent=2), encoding="utf-8", newline="\n")
    print(json.dumps({"transcript": text, "phrase_checks": checks, "vocabulary_pass": report["vocabulary_pass"]}), flush=True)


if __name__ == "__main__":
    main()
