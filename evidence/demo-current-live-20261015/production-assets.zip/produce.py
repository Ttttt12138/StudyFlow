"""Build the formal film from accepted browser ranges and authorized Ava paragraphs."""
import argparse
import asyncio
import hashlib
import json
from pathlib import Path
import sys

from PIL import Image, ImageChops, ImageDraw, ImageStat

ROOT = Path.cwd()
WORK = ROOT / "output/formal-film-production"
DEST = WORK / "candidate"
sys.path.insert(0, str(ROOT / "scripts"))
import neural_demo_audio as sound
import narrate_neural_demo as speech
from build_full_demo_video import stamp, write
from edit_neural_demo import ASS_HEADER, caption_groups

sound.WORK = WORK
speech.WORK = WORK
FFMPEG = sound.FFMPEG

# Include the actual recorded click and resulting state after these held review frames.
ACTION_SHOTS = {"application-review", "signing-review", "tuition-authorization",
                "repayment-authorization", "approval-details", "approval-confirmation", "payee-review"}


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def story():
    chapters, number = [], 0
    for index, item in enumerate(json.loads((WORK / "story.json").read_text(encoding="utf-8")), 1):
        shots = []
        for line in item["shots"]:
            number += 1
            text = line[2]
            spoken = text.replace("StudyFlow", "Study Flow").replace("U.S. dollars", "U.S. dollars")
            shots.append({"number": number, "marker": line[0], "title": line[1], "text": text,
                          "spoken_text": spoken, "tempo": line[3] if len(line) > 3 else 1.20})
        chapters.append({"id": f"chapter-{index:02d}", "title": item["title"], "shots": shots,
                         "text": " ".join(s["text"] for s in shots),
                         "spoken_text": " ".join(s["spoken_text"] for s in shots)})
    return chapters


async def synthesize(deps):
    sys.path.insert(0, str(deps))
    import edge_tts
    for chapter in story():
        generated = await speech.synthesize(edge_tts, chapter)
        # Cached speech stays valid when preceding chapters insert or remove shots.
        save(WORK / (chapter["id"] + ".tts.json"), {**generated, **chapter})
        print(chapter["id"], "synthesized", flush=True)
    save(WORK / "speech-service.json", {"provider": "Microsoft Edge online neural TTS", **speech.VOICE,
         "authorization": "User authorized sending English narration to Microsoft and requested this Ava remake",
         "normal_tempo": 1.20, "numeric_tempo": 1.12, "sent": "English narration text only"})


def frame(shot, chapter):
    canvas = Image.new("RGB", (1920, 1080), "#101e35")
    draw = ImageDraw.Draw(canvas)
    write(draw, (24, 12), "StudyFlow", 25, bold=True)
    write(draw, (205, 18), "REAL MODEL CALLS / SIMULATED FINANCIAL TRANSACTIONS", 18, "#b1c2d9", 1350)
    write(draw, (1500, 95), chapter, 23, "#71acff", 365)
    write(draw, (1500, 175), shot["title"], 40, "#f7f9fc", 370, True)
    draw.line((1500, 385, 1875, 385), fill="#354966", width=2)
    notes = ("Independent operator review. Student authorization still required." if shot["role"] != "student"
             else "Understand the options. Decide with confidence.")
    write(draw, (1500, 430), notes, 26, "#b1c2d9", 365)
    write(draw, (1500, 785), "Recorded in the current app. Waiting shortened.", 22, "#b1c2d9", 365)
    write(draw, (1500, 910), f"{shot['number']:02d} / {sum(len(c['shots']) for c in story()):02d}", 22, "#71acff")
    return canvas


def difference(path, reference):
    with Image.open(path) as actual, Image.open(reference) as expected:
        delta = ImageChops.difference(actual.convert("RGB").resize((360, 225)), expected.convert("RGB").resize((360, 225)))
        return sum(ImageStat.Stat(delta).mean) / 3


def align(take, shots):
    marks = json.loads((take / "marks.json").read_text(encoding="utf-8"))
    sources = {s["role"]: take / s["path"] for s in json.loads((take / "sources.json").read_text(encoding="utf-8"))}
    checks = []
    for shot in shots:
        if shot["marker"] == "approved-transfer-authorization":
            # The accepted automated click is brief. Hold the actual masked-password
            # frame, then show its separately recorded confirmed result in the next shot.
            source, start = sources["student"], 536.8
            reference = DEST / "source-student-approved-transfer-authorization.png"
            sound.ffmpeg(["-ss", str(start), "-i", str(source), "-frames:v", "1", str(reference)])
            shot.update({"role": "student", "source": {"path": str(source), "start": start,
                "available": 1 / 30, "screenshot": str(reference), "range": "recorded held view",
                "annotation": "Editor-selected real frame from accepted raw footage; password is masked"}})
            checks.append({"marker": shot["marker"], "source_time": start,
                           "method": "Manually inspected actual raw frame; no screenshot substitution"})
            print("Selected recorded authorization frame", start, flush=True)
            continue
        mark = next(m for m in marks if m["name"] == shot["marker"])
        source, candidates = sources[mark["role"]], []
        for offset in (0, .4, .8, 1.2, -.4):
            target = WORK / f"align-{shot['number']:02d}.png"
            sound.ffmpeg(["-ss", str(max(0, mark["start"] + offset)), "-i", str(source), "-frames:v", "1", str(target)])
            error = difference(target, take / mark["screenshot"])
            candidates.append({"offset": offset, "difference": error})
            if error < 3:
                break
        best = min(candidates, key=lambda c: c["difference"])
        assert best["difference"] < 12, (shot["marker"], candidates)
        start = mark["start"] + best["offset"]
        # Browser video begins slightly after the performance clock. Leave margin before
        # a following page reload, so a long narration never freezes a loading frame.
        end = mark["end"] + best["offset"] - .8
        if shot["marker"] in ACTION_SHOTS:
            end = mark["end"] + best["offset"] + .2
        shot.update({"role": mark["role"], "source": {"path": str(source), "start": start,
            "available": max(.3, end - start), "screenshot": mark["screenshot"],
            "range": "review through recorded action" if shot["marker"] in ACTION_SHOTS else "recorded held view"}})
        checks.append({"marker": shot["marker"], **best, "candidates": candidates})
        print("Aligned", shot["marker"], round(best["difference"], 2), flush=True)
    save(DEST / "source-alignment.json", checks)


def prepare(take):
    DEST.mkdir(parents=True, exist_ok=True)
    original = story()
    generated = [json.loads((WORK / (c["id"] + ".tts.json")).read_text(encoding="utf-8")) for c in original]
    assert all(a["text"] == b["text"] for a, b in zip(original, generated))
    generated = [{**audio, **chapter} for audio, chapter in zip(generated, original)]
    for chapter in generated:
        assert hashlib.sha256((WORK / (chapter["id"] + ".mp3")).read_bytes()).hexdigest() == chapter["audio_sha256"]
        save(WORK / (chapter["id"] + ".tts.json"), chapter)
    chapters, words = sound.assemble(generated)
    save(WORK / "audio-timeline.json", {"chapters": chapters, "words": words})
    shots = []
    for chapter in chapters:
        starts = [chapter["start"]]
        for shot in chapter["shots"][1:]:
            current = min(w["start"] for w in words if w["shot"] == shot["number"])
            prior = max(w["end"] for w in words if w["shot"] == shot["number"] - 1)
            starts.append(round(max(prior, current - .08) * 30) / 30)
        ends = starts[1:] + [chapter["start"] + chapter["duration"]]
        for shot, begin, end in zip(chapter["shots"], starts, ends):
            shots.append({**shot, "id": f"shot-{shot['number']:02d}", "start": begin,
                          "duration": round((end - begin) * 30) / 30, "chapter": chapter["title"]})
    assert sum(s["duration"] for s in shots) < 300
    assert min(s["duration"] for s in shots) > 1.5
    align(take, shots)
    captions = caption_groups(words, shots)
    ass = [f"Dialogue: 0,{stamp(c['start'], True)},{stamp(c['end'], True)},Default,,0,0,0,,{c['text']}" for c in captions]
    (WORK / "captions.ass").write_text(ASS_HEADER + "\n".join(ass) + "\n", encoding="utf-8-sig")
    srt = [f"{i}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i, c in enumerate(captions, 1)]
    (DEST / "StudyFlow_Demo_EN.srt").write_text("\n\n".join(srt) + "\n", encoding="utf-8")
    for shot in shots:
        frame(shot, shot["chapter"]).save(WORK / (shot["id"] + ".png"))
    edit = {"take": str(take), "duration": sum(s["duration"] for s in shots), "shots": shots,
            "paragraphs": chapters, "word_timing": words, "captions": captions,
            "timing": "Provider word events mapped through local tempo changes; sentence-based 30 fps cuts"}
    save(DEST / "edit-manifest.json", edit)
    print("Prepared", len(shots), "shots, seconds:", edit["duration"], flush=True)


def render():
    edit = json.loads((DEST / "edit-manifest.json").read_text(encoding="utf-8"))
    for shot in edit["shots"]:
        source = shot["source"]
        filters = (f"[1:v]fps=30,setpts=PTS-STARTPTS,scale=1440:900,"
                   f"tpad=stop_mode=clone:stop_duration={shot['duration']}[screen];[0:v][screen]overlay=24:58[v]")
        sound.ffmpeg(["-loop", "1", "-i", shot["id"] + ".png", "-ss", str(source["start"]),
            "-t", str(source["available"]), "-i", source["path"], "-filter_complex", filters,
            "-map", "[v]", "-an", "-frames:v", str(round(shot["duration"] * 30)), "-r", "30",
            "-c:v", "libx264", "-preset", "fast", "-crf", "18", "-pix_fmt", "yuv420p", shot["id"] + ".mp4"])
        print("Rendered", shot["id"], flush=True)
    (WORK / "concat.txt").write_text("\n".join(f"file '{s['id']}.mp4'" for s in edit["shots"]), encoding="utf-8")
    target = DEST / "StudyFlow_Demo_EN.mp4"
    sound.ffmpeg(["-f", "concat", "-safe", "0", "-i", "concat.txt", "-i", "continuous-narration.wav",
        "-map", "0:v:0", "-map", "1:a:0", "-vf", "subtitles=captions.ass", "-r", "30",
        "-c:v", "libx264", "-preset", "fast", "-crf", "19", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "160k", "-ar", "48000", "-movflags", "+faststart", str(target)])
    edit["sha256"] = hashlib.sha256(target.read_bytes()).hexdigest()
    save(DEST / "edit-manifest.json", edit)
    print("Final candidate", target, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["synthesize", "prepare", "render"])
    parser.add_argument("--deps", type=Path)
    parser.add_argument("--take", type=Path)
    args = parser.parse_args()
    if args.action == "synthesize":
        asyncio.run(synthesize(args.deps))
    elif args.action == "prepare":
        prepare(args.take.resolve())
    else:
        render()
