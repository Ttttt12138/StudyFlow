"""Replace one sentence in decoded PCM; retain original TTS bytes and provenance."""
from array import array
import hashlib
import json
import math
from pathlib import Path

import neural_demo_audio as sound

WORK = Path(__file__).resolve().parent
RATE = sound.RATE


def read(name):
    return json.loads((WORK / name).read_text(encoding="utf-8"))


def save(name, value):
    (WORK / name).write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8", newline="\n")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def splice_pcm(original, replacement, sample_bounds):
    left, right = sample_bounds
    assert 0 <= left <= right <= len(original) // 2
    assert len(replacement) % 2 == 0
    return original[:left * 2] + replacement + original[right * 2:]


def splice_boundaries(original, replacement, timing):
    left, right = timing["left"], timing["right"]
    delta = timing["insert_duration"] - (right - left)
    before = [dict(e) for e in original if e["offset"] / 1e7 < left]
    inserted = [{**e, "offset": round(e["offset"] + (left - timing["trim_start"]) * 1e7)} for e in replacement]
    after = [{**e, "offset": round(e["offset"] + delta * 1e7)} for e in original if e["offset"] / 1e7 >= right]
    return before + inserted + after


def decode(name, target):
    sound.ffmpeg(["-i", name, "-ar", str(RATE), "-ac", "1", target])
    return sound.read_pcm(WORK / target)


def sentence_bounds(words, pcm):
    current = [w for w in words if w["shot"] == 37]
    previous = max(w["raw_end"] for w in words if w["shot"] == 36)
    following = min(w["raw_start"] for w in words if w["shot"] == 38)
    left = sound.quiet_cut(pcm, (previous, current[0]["raw_start"]))
    right = sound.quiet_cut(pcm, (current[-1]["raw_end"], following))
    return round(left * RATE), round(right * RATE)


def voice_rms(pcm):
    voiced = [v for v in array("h", pcm) if abs(v) > 328]
    assert voiced
    return math.sqrt(sum(v * v for v in voiced) / len(voiced))


def match_level(replacement, reference):
    gain_db = max(-3, min(3, 20 * math.log10(voice_rms(reference) / voice_rms(replacement))))
    samples, gain = array("h", replacement), 10 ** (gain_db / 20)
    edge = round(.005 * RATE)
    result = array("h")
    for index, sample in enumerate(samples):
        fade = min(1, index / edge, (len(samples) - 1 - index) / edge)
        value = round(sample * gain * fade)
        assert abs(value) < 32767, "Replacement would clip"
        result.append(value)
    return result.tobytes(), gain_db


def verify_originals():
    original = read("original-production-manifest.json")
    checks = {name: sha((WORK / name).read_bytes()) for name in original
              if name.startswith("chapter-") and (name.endswith(".mp3") or name.endswith(".tts.json"))}
    assert all(checks[name] == original[name] for name in checks)
    assert len(checks) == 16
    return checks


def seam_metrics(pcm, samples):
    values = array("h", pcm)
    result = []
    for point in samples:
        window = values[max(0, point - 240):point + 240]
        rms = math.sqrt(sum(v * v for v in window) / len(window))
        result.append({"sample": point, "rms_dbfs_10ms": 20 * math.log10(max(rms, .001) / 32768),
                       "sample_jump": abs(values[point] - values[point - 1])})
    return result


def create_patch():
    originals = verify_originals()
    old, new = read("chapter-06.tts.json"), read("replacement-shot-37.tts.json")
    original = decode("chapter-06.mp3", "chapter-06-original.wav")
    replacement = decode("replacement-shot-37.mp3", "replacement-shot-37-raw.wav")
    words = sound.displayed_words(old)
    left, right = sentence_bounds(words, original)
    events = sound.word_spans(new)
    begin = round(max(0, events[0]["start"] - .12) * RATE)
    end = min(len(replacement) // 2, round((events[-1]["stop"] + .18) * RATE))
    inserted, gain = match_level(replacement[begin * 2:end * 2], original[left * 2:right * 2])
    patched = splice_pcm(original, inserted, (left, right))
    timing = {"left": left / RATE, "right": right / RATE, "trim_start": begin / RATE,
              "trim_end": end / RATE, "insert_duration": len(inserted) / (2 * RATE)}
    changed = {**old, "boundaries": splice_boundaries(old["boundaries"], new["boundaries"], timing),
               "pcm_source": "chapter-06-patched.wav", "provenance": "Locally spliced metadata, not an original provider response"}
    for shot in changed["shots"]:
        if shot["number"] == 37:
            shot["text"] = shot["spoken_text"] = new["text"]
    changed["text"] = " ".join(s["text"] for s in changed["shots"])
    changed["spoken_text"] = " ".join(s["spoken_text"] for s in changed["shots"])
    sound.displayed_words(changed)
    sound.write_pcm(WORK / changed["pcm_source"], patched)
    save("chapter-06.composite.json", changed)
    boundary = left * 2 + len(inserted)
    assert patched[:left * 2] == original[:left * 2]
    assert patched[boundary:] == original[right * 2:]
    report = {"shot": 37, "old_text": next(s["text"] for s in read("chapter-06.tts.json")["shots"] if s["number"] == 37),
        "new_text": new["text"], "voice": new["voice"], "rate": new["rate"], "local_tempo": 1.12,
        "sample_rate": RATE, "timing": timing, "replacement_gain_db": gain,
        "insert_only_fade_ms": 5, "original_pcm_sha256": sha(original), "patched_pcm_sha256": sha(patched),
        "original_prefix_sha256": sha(original[:left * 2]), "patched_prefix_sha256": sha(patched[:left * 2]),
        "original_suffix_sha256": sha(original[right * 2:]), "patched_suffix_sha256": sha(patched[boundary:]),
        "outside_replaced_sentence_pcm_identical": True, "original_mp3_and_tts_sha256": originals,
        "seams": seam_metrics(patched, (left, boundary // 2)),
        "replacement_mp3_sha256": sha((WORK / "replacement-shot-37.mp3").read_bytes()),
        "replacement_tts_sha256": sha((WORK / "replacement-shot-37.tts.json").read_bytes()),
        "method": "Sample-exact pause splice before local tempo and paragraph mastering; original PCM prefix/suffix unchanged"}
    save("sentence-replacement.json", report)
    return changed, report


if __name__ == "__main__":
    _, report = create_patch()
    print(json.dumps({k: report[k] for k in ["timing", "replacement_gain_db", "seams"]}, indent=2))
