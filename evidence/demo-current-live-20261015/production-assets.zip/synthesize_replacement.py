"""Send only the approved replacement sentence to the authorized TTS service."""
import asyncio
import json
from pathlib import Path
import sys

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
TEXT = "After password confirmation, five hundred yuan is debited, and the quoted amount in Thai baht is credited after fees."
sys.path.insert(0, str(ROOT / "scripts"))
import narrate_neural_demo as speech
speech.WORK = WORK


async def main():
    sys.path.insert(0, sys.argv[1])
    import edge_tts
    item = {"id": "replacement-shot-37", "text": TEXT, "spoken_text": TEXT,
            "shots": [{"number": 37, "text": TEXT, "tempo": 1.12}]}
    result = await speech.synthesize(edge_tts, item)
    print(json.dumps({"sentence": result["text"], "voice": result["voice"],
                      "rate": result["rate"], "sha256": result["audio_sha256"]}))


if __name__ == "__main__":
    asyncio.run(main())
