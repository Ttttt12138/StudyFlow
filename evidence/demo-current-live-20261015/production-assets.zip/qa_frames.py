"""Verify every starting frame and graphic matte; expose every action ending."""
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageChops, ImageDraw, ImageStat

import neural_demo_audio as sound

WORK = Path(__file__).resolve().parent
DEST = WORK / "candidate"


def frame(movie, time):
    result = subprocess.run([str(sound.FFMPEG), "-v", "error", "-ss", str(time), "-i", str(movie),
                             "-frames:v", "1", "-pix_fmt", "rgb24", "-f", "rawvideo", "-"],
                            capture_output=True, check=True)
    return Image.frombytes("RGB", (1920, 1080), result.stdout)


def difference(actual, reference):
    delta = ImageChops.difference(actual.convert("RGB"), reference.convert("RGB"))
    return sum(ImageStat.Stat(delta).mean) / 3


def save(name, value):
    (DEST / name).write_text(json.dumps(value, indent=2), encoding="utf-8", newline="\n")


def main():
    edit = json.loads((DEST / "edit-manifest.json").read_text(encoding="utf-8"))
    movie, starts, mattes, actions = DEST / "StudyFlow_Demo_EN.mp4", [], [], []
    for shot in edit["shots"]:
        actual = frame(movie, shot["start"] + .001)
        with Image.open(Path(edit["take"]) / shot["source"]["screenshot"]) as reference:
            error = difference(actual.crop((24, 58, 1464, 958)).resize((360, 225)), reference.resize((360, 225)))
        starts.append({"shot": shot["id"], "marker": shot["marker"], "difference": error})
        with Image.open(WORK / (shot["id"] + ".png")) as reference:
            regions = [(0, 0, 1920, 58), (1464, 58, 1920, 958)]
            errors = [difference(actual.crop(box), reference.crop(box)) for box in regions]
        mattes.append({"shot": shot["id"], "header_difference": errors[0], "side_panel_difference": errors[1]})
        if shot["source"]["range"] != "recorded held view":
            end = frame(movie, shot["start"] + shot["duration"] - 1 / 30)
            actions.append((shot, end))
    sheet = Image.new("RGB", (1280, ((len(actions) + 1) // 2) * 390), "#101e35")
    draw = ImageDraw.Draw(sheet)
    for index, (shot, ending) in enumerate(actions):
        x, y = (index % 2) * 640, (index // 2) * 390
        sheet.paste(ending.resize((640, 360)), (x, y))
        draw.text((x + 8, y + 364), f"{shot['number']:02}: {shot['marker']} ending", fill="white")
    sheet.save(DEST / "action-end-review.jpg", quality=93)
    save("start-frame-check.json", starts)
    save("matte-check.json", mattes)
    assert all(s["difference"] < 4 for s in starts), [s for s in starts if s["difference"] >= 4]
    assert all(max(s["header_difference"], s["side_panel_difference"]) < 4 for s in mattes)
    print("All 54 starts and graphic mattes verified; seven action endings ready for review")


if __name__ == "__main__":
    main()
