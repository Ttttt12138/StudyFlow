"""Offline speech check using the existing local SenseVoice installation."""
import json
import os
from pathlib import Path
import re
import sys

ROOT = Path.cwd()
WORK = Path(__file__).resolve().parent
for key in ("HF_HUB_OFFLINE", "TRANSFORMERS_OFFLINE", "HF_HUB_DISABLE_TELEMETRY"):
    os.environ[key] = "1"
for key in ("HF_HOME", "MODELSCOPE_CACHE", "NUMBA_CACHE_DIR", "TORCH_HOME"):
    os.environ[key] = str(WORK / "validation-cache" / key.lower())
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(WORK))
import verify_neural_speech as check
check.WORK = WORK


def tokens(text):
    text = text.lower().replace("study flow", "studyflow").replace("u.s.", "us")
    for phrase, number in [("forty-eight thousand", "48000"), ("forty eight thousand", "48000"),
                           ("thirty thousand", "30000"), ("five hundred", "500"),
                           ("one thousand", "1000"), ("four", "4")]:
        text = text.replace(phrase, number)
    text = re.sub(r"(?<=\d),(?=\d)", "", text)
    return re.findall(r"[a-z0-9]+", text)


def main():
    import numpy as np
    from funasr import AutoModel
    models = Path(r"D:\Qoder-project\ai girl\.runtime\sensevoice\checkpoints")
    model = AutoModel(model=str(models / "sensevoice"), device="cpu", ncpu=4,
        vad_model=str(models / "vad"), vad_kwargs={"max_single_segment_time": 30000, "device": "cpu"},
        disable_update=True, disable_pbar=True, trust_remote_code=False)
    check.tokens = tokens
    chapters = json.loads((WORK / "audio-timeline.json").read_text(encoding="utf-8"))["chapters"]
    results = [check.recognize(model, chapter, np) for chapter in chapters]
    report = {"method": "Offline SenseVoice on all eight mastered paragraphs; no audio uploaded",
        "limitation": "ASR differences do not measure human listening quality or phonetic timing",
        "word_error_rate": sum(row["word_errors"] for row in results) / sum(row["reference_words"] for row in results),
        "numbers_match": all(row["numbers_expected"] == row["numbers_observed"] for row in results),
        "paragraphs": results}
    (WORK / "candidate").mkdir(exist_ok=True)
    (WORK / "candidate/speech-check.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "paragraphs"}), flush=True)


if __name__ == "__main__":
    main()
